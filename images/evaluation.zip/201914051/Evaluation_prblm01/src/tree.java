import javax.swing.text.html.HTMLDocument;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class tree {
    public static void main(String[] args) {
        TreeSet<String> t=new TreeSet<>();
        t.add("Orange");
        t.add("Pink");
        t.add("Purple");
        t.add("Black");
        t.add("Blue");
        t.add("Indigo");
        t.add("Red");
        t.add("Yellow");
        System.out.println(t);
        System.out.println("REverse order");
        Iterator itr=t.descendingIterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
        //Cloned tree
        TreeSet clone=new TreeSet();
        clone=(TreeSet)t.clone();
        System.out.println(clone);

        //Delete a given String
        Scanner scan=new Scanner(System.in);
        String color=scan.nextLine();
        for(String i:t){
            if(i.equals(color));
            {
                t.remove(i);
            }
        }
        //Delete the last String
        System.out.println("Last String:"+t.pollLast());
        t.remove(t.pollLast());

        //Element strictly less than or equal
        Scanner scan2=new Scanner(System.in);
        String color2=scan2.nextLine();






    }
}
