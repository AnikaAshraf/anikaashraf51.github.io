import javax.swing.*;
import java.awt.event.*;

public class degree {
    private JPanel mainpanel;
    private JTextField textField1;
    private JTextField textField2;
    private JButton convertButton;
    private JButton button2;
    private JLabel click;
    int count=0;

    public degree() {
        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a= Integer.parseInt(textField1.getText());
                float F=((9*a)/5)+32;
                //String b=String.v
                textField2.setText(String.valueOf(F));
            }
        });

        button2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                count++;
                click.setText("Number of times button clicked:"+count);

            }
        });
    }
    JPanel getpanel(){
        return mainpanel;
    }
}
